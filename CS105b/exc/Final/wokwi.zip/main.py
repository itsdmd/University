# http://www.hivemq.com/demos/websocket-client/

import network
import time
from machine import Pin
import dht
import ujson
from umqtt.simple import MQTTClient

MQTT_CLIENT_ID = "105b-Final-030927"
MQTT_BROKER    = "broker.hivemq.com"
MQTT_USER      = ""
MQTT_PASSWORD  = ""
MQTT_TOPIC     = "030927"     # Send string composed by Arduino
MQTT_TOPIC_CB  = "030927-cb"  # Send string sent from Node-RED

SND_MSG = "006270500"   # Received from Arduino via serial ports


# WiFi
print("Connecting to WiFi", end="")
sta_if = network.WLAN(network.STA_IF)
sta_if.active(True)
sta_if.connect('Wokwi-GUEST', '')
while not sta_if.isconnected():
  print(".", end="")
  time.sleep(0.1)
print(" Connected!")


# MQTT
print("Connecting to MQTT server... ", end="")

client = MQTTClient(MQTT_CLIENT_ID, MQTT_BROKER, user=MQTT_USER, password=MQTT_PASSWORD, keepalive=60)
client.connect()

def callback(topic, msg):
  RCV_MSG = msg.decode()
  print("Received message: " + RCV_MSG)
  # Send to Arduino via serial ports

client.set_callback(callback)
client.subscribe(MQTT_TOPIC_CB)

print("Connected!")

# Main
prev_msg = ""
while True:
  client.check_msg()

  if SND_MSG != prev_msg:
    print("Updated!")
    print("Reporting to MQTT topic {}: {}".format(MQTT_TOPIC, SND_MSG))
    client.publish(MQTT_TOPIC, SND_MSG)
    prev_msg = SND_MSG
  else:
    print("No change")

  time.sleep(2)
