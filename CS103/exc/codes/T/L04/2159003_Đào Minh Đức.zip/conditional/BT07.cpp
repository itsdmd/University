#include <iostream>
using namespace std;

int main()
{
    const int   p1 = 15000, p2 = 13500, p3 = 11000,
                s1 = 1, s2 = 2, s3 = 5, s4 = 6, s5 = 120;
    long long n;    // Do đề bài không nêu trường hợp cho các đoạn đường giữa các mốc km nên em đã mặc định dữ liệu nhập vào là số nguyên
    double p;

    cout << endl << "Nhap quang duong (km): ";
    cin >> n;

    if (n <= 0)
    {
        cout << endl << "Du lieu nhap vao phai lon hon 0." << endl;
        main();
    }

    else
    {
        if (n <= s1)
        {
            p = p1;
        }

        else if (s2 <= n && n <= s3)
        {
            p = p1 + ((n-s2) * p2);
        }

        else if (s4 <= n && n <= s5)
        {
            p = p1 + ((s3-s2) * p2) + ((n-s4) * p3);
        }

        else
        {
            p = (p1 + ((s3-s2) * p2) + ((n-s4) * p3)) - ((p1 + ((s3-s2) * p2) + ((n-s4) * p3)) * 0.1);
        }

        cout << "Tong tien phai tra la: " << fixed << p << endl;
    }
    
    return 0;
}
