# exc
 
```ccard
type: folder_brief_live
```
 
[[Courses/CS109/exc/subs/subs]]