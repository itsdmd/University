// Construct class Monomial with the following methods:
// - input: enter monomial from keyboard.
// - output: print monomial to screen.
// - getCoef/setCoef: get/update coefficient of monomial.
// - getExpo/setExpo: get/update exponent of monomial.
// - evaluate: return result of evaluating monomial with float number.
// - derive: return the derivative of monomial.
// - mul: return the product of multiplying two monomials.

#include <iostream>
#include "src/mnm.cpp"



/// -------------------------------- main() -------------------------------- ///
int main() {
	//
	
	return 0;
}