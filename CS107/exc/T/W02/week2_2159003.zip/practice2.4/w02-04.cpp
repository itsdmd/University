// Construct class Array of integers with the following methods:
// - input: enter array size and elements from keyboard.
// - output: print array elements to screen.
// - getSize/setSize: get/update size of array.
// - getElement/setElement: get/update element at specified index.
// - find: look for an element and return found index ( -1 if not found).
// - sort: sort array, the sort criteria can be customized.

#include <iostream>
#include "src/array.cpp"



/// -------------------------------- main() -------------------------------- ///
int main() {
	//
	
	return 0;
}